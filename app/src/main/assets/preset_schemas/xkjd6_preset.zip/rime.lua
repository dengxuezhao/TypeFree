-- TypeFree librime-lua entry for 星空键道 6 (xkjd6)
collectgarbage("setpause", 50)
collectgarbage("setstepmul", 400)

topup_processor = require("topup_processor")
